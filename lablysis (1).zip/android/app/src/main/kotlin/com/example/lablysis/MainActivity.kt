package com.example.lablysis

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
